/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue;

import com.algonquincollege.makerqueue.controllers.PrintJobController;
import com.algonquincollege.makerqueue.models.ArchivedPrintJob;
import com.algonquincollege.makerqueue.models.PrintJob;
import com.algonquincollege.makerqueue.models.PrintJobData;
import com.algonquincollege.makerqueue.models.repositories.ArchivedPrintJobRepository;
import com.algonquincollege.makerqueue.models.repositories.FileRepository;
import com.algonquincollege.makerqueue.models.repositories.PrintJobRepository;
import com.algonquincollege.makerqueue.utill.PrintJobComparator;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * The MakerqueueApplicationTests class contains unit tests for the MakerQueue application.
 * It uses the Spring Boot testing framework and the MockMvc library for testing the REST API endpoints.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-06-26
 */
@SpringBootTest
@AutoConfigureMockMvc
class MakerqueueApplicationTests {
    private PrintJobController printJobController;
    private PrintJobRepository printJobRepository;
    private ArchivedPrintJobRepository archiveJobRepository;
    private FileRepository fileRepository;

    @BeforeEach
    public void setUp() {
        printJobRepository = Mockito.mock(PrintJobRepository.class);
        archiveJobRepository = Mockito.mock(ArchivedPrintJobRepository.class);
        fileRepository = Mockito.mock(FileRepository.class);
        printJobController = new PrintJobController(printJobRepository, archiveJobRepository, fileRepository);
    }

    @Test
    public void testGetAllPrintJobs() {
        List<PrintJob> printJobs = new ArrayList<>();

        PrintJobComparator comparator = new PrintJobComparator(); // Create the comparator

        printJobs.add(new PrintJob(new PrintJobData("Test Print Job", "test@example.com", "Test description", "1")));
        printJobs.add(new PrintJob(new PrintJobData("Test Print Job2", "test2@example.com", "Test 2 description", "2")));

        when(printJobRepository.findAll()).thenReturn(printJobs);

        List<PrintJob> result = printJobController.getAllPrintJobs();

        printJobs.sort(comparator);
        result.sort(comparator);

        assertEquals(printJobs, result);
    }

    @Test
    public void testGetPrintJobById_ExistingId() {
        ObjectId id = new ObjectId();
        PrintJob printJob = new PrintJob(new PrintJobData("Test Print Job", "test@example.com", "Test description", "1"));
        Optional<PrintJob> optionalPrintJob = Optional.of(printJob);

        when(printJobRepository.findById(id)).thenReturn(optionalPrintJob);

        ResponseEntity<?> response = printJobController.getPrintJobById(id.toString());

        assertEquals(HttpStatus.OK, response.getStatusCode());

        PrintJob responsePrintJob = (PrintJob) response.getBody();
        assert responsePrintJob != null;
        assertEquals(0, new PrintJobComparator().compare(printJob, responsePrintJob));
    }

    @Test
    public void testGetPrintJobById_NonExistingId() {
        ObjectId id = new ObjectId();

        when(printJobRepository.findById(id)).thenReturn(Optional.empty());

        ResponseEntity<?> response = printJobController.getPrintJobById(id.toString());

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testCreatePrintJob() {
        PrintJobData printjobData = new PrintJobData("Test Print Job", "test@example.com", "Test description", "1");
        PrintJob printJob = new PrintJob(printjobData);

        ResponseEntity<?> response = printJobController.createPrintJob(printjobData);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        PrintJob responsePrintJob = (PrintJob) response.getBody();
        assert responsePrintJob != null;
        printJob.setUuid(responsePrintJob.getUuid()); // TODO: fix Hack
        assertEquals(0, new PrintJobComparator().compare(printJob, responsePrintJob));
    }

    @Test
    public void testUpdatePrintJob_ExistingId() {
        PrintJob existingPrintJob = new PrintJob(new PrintJobData("Existing Print Job", "test@example.com", "Existing description", "1"));
        ObjectId id = new ObjectId(existingPrintJob.getUuid());
        Optional<PrintJob> optionalPrintJob = Optional.of(existingPrintJob);
        PrintJob updatedPrintJob = new PrintJob(new PrintJobData("Updated Print Job", "updated@example.com", "Updated description", "1"));
        updatedPrintJob.setUuid(existingPrintJob.getUuid()); // TODO: fix Hack

        when(printJobRepository.findById(id)).thenReturn(optionalPrintJob);

        ResponseEntity<?> response = printJobController.updatePrintJob(id.toString(), updatedPrintJob.getPrintJobData());

        assertEquals(HttpStatus.OK, response.getStatusCode());

        PrintJob responsePrintJob = (PrintJob) response.getBody();
        assert responsePrintJob != null;
        assertEquals(0, new PrintJobComparator().compare(updatedPrintJob, responsePrintJob));
    }

    @Test
    public void testUpdatePrintJob_NonExistingId() {
        ObjectId id = new ObjectId();
        PrintJob updatedPrintJob = new PrintJob(new PrintJobData("Updated Print Job", "updated@example.com", "Updated description", "1"));

        when(printJobRepository.findById(id)).thenReturn(Optional.empty());

        ResponseEntity<?> response = printJobController.updatePrintJob(id.toString(), updatedPrintJob.getPrintJobData());

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testDeletePrintJob_ExistingId() {
        PrintJob existingPrintJob = new PrintJob(new PrintJobData("Existing Print Job", "test@example.com", "Existing description", "1"));
        ObjectId id = new ObjectId(existingPrintJob.getUuid());
        Optional<PrintJob> optionalPrintJob = Optional.of(existingPrintJob);

        when(printJobRepository.findById(id)).thenReturn(optionalPrintJob);

        ResponseEntity<?> response = printJobController.deletePrintJob(id.toString());

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    public void testDeletePrintJob_NonExistingId() {
        ObjectId id = new ObjectId();

        when(printJobRepository.findById(id)).thenReturn(Optional.empty());

        ResponseEntity<?> response = printJobController.deletePrintJob(id.toString());

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testArchivePrintJobSuccess() {
        // Mock a PrintJob and its ID
        PrintJob printJob = new PrintJob(new PrintJobData("Test Print Job", "test@example.com", "Test description", "1"));
        printJob.setUuid(new ObjectId().toString());
        String printJobId = printJob.getUuid();

        // Mock repository behavior
        Mockito.when(printJobRepository.findById(new ObjectId(printJobId))).thenReturn(Optional.of(printJob));

        // Call the method and check the response
        ResponseEntity<?> response = printJobController.archivePrintJob(printJobId);
        // Assert that the response is OK
        assertEquals(HttpStatus.OK, response.getStatusCode());

        // Verify that the repositories were called as expected
        Mockito.verify(archiveJobRepository).save(Mockito.any());
        Mockito.verify(printJobRepository).deleteById(new ObjectId(printJobId));
    }

    @Test
    public void testArchivePrintJobNotFound() {
        // Mock a non-existing PrintJob ID
        String nonExistingPrintJobId = new ObjectId().toString();

        // Mock repository behavior
        Mockito.when(printJobRepository.findById(new ObjectId(nonExistingPrintJobId))).thenReturn(Optional.empty());

        // Call the method and check the response
        ResponseEntity<?> response = printJobController.archivePrintJob(nonExistingPrintJobId);
        // Assert that the response is "Not Found"
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

        // Verify that the repositories were not called
        Mockito.verify(archiveJobRepository, Mockito.never()).save(Mockito.any());
        Mockito.verify(printJobRepository, Mockito.never()).deleteById(new ObjectId(nonExistingPrintJobId));
    }

    @Test
    public void testUnarchivePrintJobSuccess() {
        // Mock an ArchivedPrintJob and its ID
        ArchivedPrintJob archivedPrintJob = new ArchivedPrintJob(new PrintJob(new PrintJobData("Test Print Job", "test@example.com", "Test description", "1")));
        archivedPrintJob.setUuid(new ObjectId().toString());
        String archivedPrintJobId = archivedPrintJob.getUuid();

        // Mock repository behavior
        Mockito.when(archiveJobRepository.findById(new ObjectId(archivedPrintJobId))).thenReturn(Optional.of(archivedPrintJob));

        // Call the method and check the response
        ResponseEntity<?> response = printJobController.unarchivePrintJob(archivedPrintJobId);
        // Assert that the response is OK
        assertEquals(HttpStatus.OK, response.getStatusCode());

        // Verify that the repositories were called as expected
        Mockito.verify(printJobRepository).save(Mockito.any());
        Mockito.verify(archiveJobRepository).deleteById(new ObjectId(archivedPrintJobId));
    }

    @Test
    public void testUnarchivePrintJobNotFound() {
        // Mock a non-existing ArchivedPrintJob ID
        String nonExistingArchivedPrintJobId = new ObjectId().toString();

        // Mock repository behavior
        Mockito.when(archiveJobRepository.findById(new ObjectId(nonExistingArchivedPrintJobId))).thenReturn(Optional.empty());

        // Call the method and check the response
        ResponseEntity<?> response = printJobController.unarchivePrintJob(nonExistingArchivedPrintJobId);
        // Assert that the response is "Not Found"
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

        // Verify that the repositories were not called
        Mockito.verify(printJobRepository, Mockito.never()).save(Mockito.any());
        Mockito.verify(archiveJobRepository, Mockito.never()).deleteById(new ObjectId(nonExistingArchivedPrintJobId));
    }

}

