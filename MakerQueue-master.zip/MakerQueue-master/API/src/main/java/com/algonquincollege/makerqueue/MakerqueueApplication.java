/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The MakerqueueApplication class is the entry point of the MakerQueue application.
 * It starts the application by running the SpringApplication.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-06-26
 */
@SpringBootApplication
public class MakerqueueApplication {

    /**
     * The main method is the entry point of the application.
     * It starts the MakerQueue application by running the SpringApplication.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(MakerqueueApplication.class, args);
    }

}
