package com.algonquincollege.makerqueue.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "files")
public class File {
    @Id
    @Indexed(unique = true)
    private String fileId;
    private String originalFileName;
    private String randomizedFileName;
    private String fileType;
    private long fileSize;
    private byte[] fileContent;

    public File(String originalFileName, String randomizedFileName, String fileType, long fileSize, byte[] fileContent) {
        this.originalFileName = originalFileName;
        this.randomizedFileName = randomizedFileName;
        this.fileType = fileType;
        this.fileSize = fileSize;
        this.fileContent = fileContent;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public String getRandomizedFileName() {
        return randomizedFileName;
    }

    public void setRandomizedFileName(String randomizedFileName) {
        this.randomizedFileName = randomizedFileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }
}