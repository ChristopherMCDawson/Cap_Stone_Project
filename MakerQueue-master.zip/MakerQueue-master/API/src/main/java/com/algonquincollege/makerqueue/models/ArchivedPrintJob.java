/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue.models;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * Represents an archived print job with a unique identifier, name, email, description and an archive
 * date timestamp to know when it was archived.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-10-05
 */
@Document(collection = "archivedprintjobs")
public class ArchivedPrintJob {
    @Id
    @Indexed(unique = true)
    private ObjectId uuid;
    private PrintJobData printJobData;
    private Date archiveTimestamp;

    public ArchivedPrintJob(PrintJob printJob) {
        PrintJobData tempData = printJob.getPrintJobData();
        PrintJobData.validate(tempData.getName(), tempData.getEmail(), tempData.getDescription());
        this.uuid = new ObjectId(printJob.getUuid());
        printJobData = new PrintJobData(tempData.getName(), tempData.getEmail(), tempData.getDescription(), tempData.getFileId());
        archiveTimestamp = new Date();
    }

    public ArchivedPrintJob() {
    }

    public PrintJobData getPrintJobData() {
        return printJobData;
    }

    public String getUuid() {
        return uuid.toString();
    }

    public void setUuid(String uuid) {
        this.uuid = new ObjectId(uuid);
    }

    public String getName() {
        return printJobData.getName();
    }

    public String getEmail() {
        return printJobData.getEmail();
    }

    public String getDescription() {
        return printJobData.getDescription();
    }

    public String getStatus() {
        return printJobData.getStatus();
    }

    public String getPriority() {
        return printJobData.getPriority();
    }

    public Date getArchiveTimestamp() {
        return archiveTimestamp;
    }

    public void setArchiveTimestamp(Date archiveTimestamp) {
        this.archiveTimestamp = archiveTimestamp;
    }
}
