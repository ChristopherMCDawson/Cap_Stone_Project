package com.algonquincollege.makerqueue.models.repositories;

import com.algonquincollege.makerqueue.models.File;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FileRepository extends MongoRepository<File, String> {
}
