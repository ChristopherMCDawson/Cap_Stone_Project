package com.algonquincollege.makerqueue.utill;

import com.algonquincollege.makerqueue.models.PrintJob;
import org.bson.types.ObjectId;

import java.util.Comparator;

public class PrintJobComparator implements Comparator<PrintJob> {

    @Override
    public int compare(PrintJob job1, PrintJob job2) {
        ObjectId uuid1 = new ObjectId(job1.getUuid());
        ObjectId uuid2 = new ObjectId(job2.getUuid());
        return uuid1.compareTo(uuid2);
    }
}
