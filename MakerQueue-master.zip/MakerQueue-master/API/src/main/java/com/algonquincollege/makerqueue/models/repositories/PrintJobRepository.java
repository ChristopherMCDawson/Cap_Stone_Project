/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue.models.repositories;

import com.algonquincollege.makerqueue.models.PrintJob;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * The PrintJobRepository interface extends the MongoRepository interface,
 * providing methods for accessing and managing print jobs in the database.
 * It uses UUID as the identifier type for print jobs.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-06-26
 */
public interface PrintJobRepository extends MongoRepository<PrintJob, ObjectId> {
    List<PrintJob> findByPrintJobDataJobIDContainingIgnoreCase(String JobID);

    List<PrintJob> findByPrintJobDataNameContainingIgnoreCase(String name);

    List<PrintJob> findByPrintJobDataEmailContainingIgnoreCase(String email);
}
