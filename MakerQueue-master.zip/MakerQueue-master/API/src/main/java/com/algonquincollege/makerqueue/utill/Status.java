package com.algonquincollege.makerqueue.utill;

import java.util.HashMap;
import java.util.Map;

public enum Status {
    TO_DO("To Do"),
    IN_PROGRESS("In Progress"),
    DONE("Done"),
    ARCHIVED("Archived");

    // Create a reverse mapping from string to enum value
    private static final Map<String, Status> statusStringMap = new HashMap<>();

    static {
        for (Status status : values()) {
            statusStringMap.put(status.statusString, status);
        }
    }

    private final String statusString;

    Status(String statusString) {
        this.statusString = statusString;
    }

    // Setter method to set the status from a string
    public static Status setStatusFromString(String statusString) {
        Status status = statusStringMap.get(statusString);
        if (status == null) {
            throw new IllegalArgumentException("Invalid status string: " + statusString);
        }
        return status;
    }

    @Override
    public String toString() {
        return statusString;
    }
}


