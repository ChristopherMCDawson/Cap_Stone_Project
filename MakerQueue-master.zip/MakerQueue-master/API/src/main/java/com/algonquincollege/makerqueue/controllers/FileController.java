package com.algonquincollege.makerqueue.controllers;

import com.algonquincollege.makerqueue.models.File;
import com.algonquincollege.makerqueue.models.repositories.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;
import java.util.UUID;

/**
 * This class represents the controller for managing files in the MakerQueue application.
 * It handles HTTP requests related to files, such as retrieving, creating, updating, and deleting files.
 * Only authorized users have permission to perform these operations.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-09-07
 */
@RestController
@RequestMapping("/api/files")
@CrossOrigin(origins = "http://localhost:3000")
public class FileController {

    private final FileRepository fileRepository;

    @Autowired
    public FileController(FileRepository fileRepository) {
        this.fileRepository = fileRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            // Process and validate the file
            String originalFileName = file.getOriginalFilename();
            String fileType = file.getContentType();
            long fileSize = file.getSize();
            byte[] fileContent = file.getBytes();

            // Generate a randomized file name
            String randomizedFileName = generateRandomFileName();

            // Create a FileDocument instance
            File fileDocument = new File(originalFileName, randomizedFileName, fileType, fileSize, fileContent);

            // Save the file document to the repository
            fileRepository.save(fileDocument);

            return ResponseEntity.status(HttpStatus.CREATED).body(fileDocument.getFileId());
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error uploading the file.");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> downloadFile(@PathVariable("id") String id) {
        Optional<File> fileDocument;
        fileDocument = fileRepository.findById(id);
        if (fileDocument.isPresent()) {
            File document = fileDocument.get();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.builder("attachment")
                    .filename(document.getOriginalFileName())
                    .build());

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.parseMediaType(document.getFileType()))
                    .contentLength(document.getFileSize())
                    .body(document.getFileContent());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFile(@PathVariable("id") String id) {
        Optional<File> fileDocument = fileRepository.findById(id);
        if (fileDocument.isPresent()) {
            File document = fileDocument.get();
            fileRepository.deleteById(document.getFileId());
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/name/{id}")
    public ResponseEntity<?> getFileName(@PathVariable("id") String id) {
        Optional<File> fileDocument = fileRepository.findById(id);
        if (fileDocument.isPresent()) {
            File document = fileDocument.get();
            return ResponseEntity.ok().body(document.getOriginalFileName());
        }
        return ResponseEntity.notFound().build();
    }

    private String generateRandomFileName() {
        return UUID.randomUUID().toString();
    }
}