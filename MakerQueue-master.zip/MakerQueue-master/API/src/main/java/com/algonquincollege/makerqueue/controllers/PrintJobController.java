/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue.controllers;

import com.algonquincollege.makerqueue.models.ArchivedPrintJob;
import com.algonquincollege.makerqueue.models.PrintJob;
import com.algonquincollege.makerqueue.models.PrintJobData;
import com.algonquincollege.makerqueue.models.repositories.ArchivedPrintJobRepository;
import com.algonquincollege.makerqueue.models.repositories.FileRepository;
import com.algonquincollege.makerqueue.models.repositories.PrintJobRepository;
import com.algonquincollege.makerqueue.utill.Priority;
import com.algonquincollege.makerqueue.utill.Status;
import org.bson.types.ObjectId;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * This class represents the controller for managing print jobs in the MakerQueue application.
 * It handles HTTP requests related to print jobs, such as retrieving, creating, updating, and deleting print jobs.
 * Only authorized users have permission to perform these operations.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-10-05
 */
@RestController
@RequestMapping("/api/printjobs")
@CrossOrigin(origins = "http://localhost:3000")
public class PrintJobController {
    private final PrintJobRepository printJobRepository;
    private final ArchivedPrintJobRepository archivedPrintJobRepository;
    private final FileRepository fileRepository;

    /**
     * Constructs a new PrintJobController with the specified PrintJobRepository.
     *
     * @param printJobRepository the repository for accessing and managing print jobs
     */
    public PrintJobController(PrintJobRepository printJobRepository, ArchivedPrintJobRepository archivedPrintJobRepository, FileRepository fileMetadataRepository) {
        this.printJobRepository = printJobRepository;
        this.archivedPrintJobRepository = archivedPrintJobRepository;
        this.fileRepository = fileMetadataRepository;
    }

    /**
     * Retrieves all print jobs from the repository.
     *
     * @return a list of all print jobs
     */
    @GetMapping("")
    public List<PrintJob> getAllPrintJobs() {
        return printJobRepository.findAll();
    }

    /**
     * Retrieves all archived print jobs from the repository.
     *
     * @return a list of all archived print jobs
     */
    @GetMapping("/archived")
    public List<ArchivedPrintJob> getAllArchivedPrintJobs() {
        return archivedPrintJobRepository.findAll();
    }

    /**
     * Retrieves a specific print job by its ID.
     *
     * @param id the ID of the print job to retrieve
     * @return the print job if found, or a "Not Found" response if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getPrintJobById(@PathVariable("id") String id) {
        Optional<PrintJob> printJob = printJobRepository.findById(new ObjectId(id));
        if (printJob.isPresent()) {
            return ResponseEntity.ok(printJob.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Searches for the print jobs with a certain uuid, name or email.
     *
     * @param query query to search with
     * @return a print job or list of print jobs
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchPrintJobs(@RequestParam(value = "query", required = false) String query) {
        if (query != null) {
            // Search by job id
            List<PrintJob> printJobs = printJobRepository.findByPrintJobDataJobIDContainingIgnoreCase(query);
            if (!printJobs.isEmpty()) {
                return ResponseEntity.ok(printJobs);
            }
            // Search by email
            printJobs = printJobRepository.findByPrintJobDataEmailContainingIgnoreCase(query);
            if (!printJobs.isEmpty()) {
                return ResponseEntity.ok(printJobs);
            }
            // Search by name
            printJobs = printJobRepository.findByPrintJobDataNameContainingIgnoreCase(query);
            if (!printJobs.isEmpty()) {
                return ResponseEntity.ok(printJobs);
            }
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Searches for the archived print jobs with a certain uuid, name or email.
     *
     * @param query query to search with
     * @return a print job or list of print jobs
     */
    @GetMapping("/archived/search")
    public ResponseEntity<?> searchArchivedPrintJobs(@RequestParam(value = "query", required = false) String query) {
        if (query != null) {
            // Attempt to determine the search criteria
            if (ObjectId.isValid(query)) {
                return getArchivedPrintJobById(query);
            }
            // Search by email
            List<ArchivedPrintJob> printJobs = archivedPrintJobRepository.findByPrintJobDataEmailContainingIgnoreCase(query);
            if (!printJobs.isEmpty()) {
                return ResponseEntity.ok(printJobs);
            }
            // Search by name
            printJobs = archivedPrintJobRepository.findByPrintJobDataNameContainingIgnoreCase(query);
            if (!printJobs.isEmpty()) {
                return ResponseEntity.ok(printJobs);
            }
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Retrieves a specific archived print job by its ID.
     *
     * @param id the ID of the print job to retrieve
     * @return the print job if found, or a "Not Found" response if not found
     */
    @GetMapping("/archived/{id}")
    public ResponseEntity<?> getArchivedPrintJobById(@PathVariable("id") String id) {
        Optional<ArchivedPrintJob> archivedPrintJob = archivedPrintJobRepository.findById(new ObjectId(id));
        if (archivedPrintJob.isPresent()) {
            return ResponseEntity.ok(archivedPrintJob.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Retrieves the strings that represent the status enum
     *
     * @return string list of the enums
     */
    @GetMapping("/status")
    public List<String> getStatusList() {
        List<String> statusStrings = new ArrayList<>();
        for (Status status : Status.values()) {
            statusStrings.add(status.toString());
        }
        return statusStrings;
    }

    /**
     * Retrieves the strings that represent the priority enum
     *
     * @return string list of the enums
     */
    @GetMapping("/priority")
    public List<String> getPriorityList() {
        List<String> priorityStrings = new ArrayList<>();
        for (Priority priority : Priority.values()) {
            priorityStrings.add(priority.toString());
        }
        return priorityStrings;
    }

    /**
     * Creates a new print job.
     *
     * @param printJobData the data to create the print job from
     * @return a "Created" response with the created print job if successful,
     * or a "Bad Request" response with validation errors if the print job is not valid
     */
    @PostMapping("")
    public ResponseEntity<?> createPrintJob(@RequestBody PrintJobData printJobData) {
        try {
            PrintJob printJob = new PrintJob(printJobData);
            printJobRepository.save(printJob);
            return ResponseEntity.status(HttpStatus.CREATED).body(printJob);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid PrintJob fields");
        }
    }

    /**
     * Archives a print job with the specified ID.
     *
     * @param id the ID of the print job to archive
     * @return a successful response if the print job is archived,
     * or a "Not Found" response if the print job is not found
     */
    @PostMapping("/{id}/archive")
    public ResponseEntity<?> archivePrintJob(@PathVariable("id") String id) {
        Optional<PrintJob> printJob = printJobRepository.findById(new ObjectId(id));
        if (printJob.isPresent()) {
            ArchivedPrintJob archivedPrintJob = new ArchivedPrintJob(printJob.get());

            archivedPrintJobRepository.save(archivedPrintJob);

            printJobRepository.deleteById(new ObjectId(id));

            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Un-archives a previously archived print job with the specified ID.
     *
     * @param id the ID of the archived print job to unarchive
     * @return a successful response if the print job is unarchived,
     * or a "Not Found" response if the archived print job is not found
     */
    @PostMapping("/{id}/unarchive")
    public ResponseEntity<?> unarchivePrintJob(@PathVariable("id") String id) {
        Optional<ArchivedPrintJob> archivedPrintJob = archivedPrintJobRepository.findById(new ObjectId(id));
        if (archivedPrintJob.isPresent()) {
            PrintJob unarchivedPrintJob = new PrintJob(archivedPrintJob.get());

            printJobRepository.save(unarchivedPrintJob);

            archivedPrintJobRepository.deleteById(new ObjectId(id));

            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Updates an existing print job with the specified ID.
     *
     * @param id           the ID of the print job to update
     * @param printJobData data to update the printjob with
     * @return the updated print job if successful,
     * or a "Not Found" response if the print job is not found,
     * or a "Bad Request" response with validation errors if the print job is not valid
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updatePrintJob(@PathVariable("id") String id, @RequestBody PrintJobData printJobData) {
        Optional<PrintJob> existingPrintJob = printJobRepository.findById(new ObjectId(id));
        if (existingPrintJob.isPresent()) {
            try {
                existingPrintJob.get().getPrintJobData().setName(printJobData.getName());
                existingPrintJob.get().getPrintJobData().setEmail(printJobData.getEmail());
                existingPrintJob.get().getPrintJobData().setDescription(printJobData.getDescription());
                existingPrintJob.get().getPrintJobData().setStatus(printJobData.getStatus());
                existingPrintJob.get().getPrintJobData().setPriority(printJobData.getPriority());
                if (Status.ARCHIVED.toString().equals(existingPrintJob.get().getStatus())) {
                    return archivePrintJob(id);
                }
                printJobRepository.save(existingPrintJob.get());
                return ResponseEntity.ok(existingPrintJob.get());
            } catch (IllegalArgumentException ex) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid PrintJob fields");
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Deletes a print job with the specified ID.
     *
     * @param id the ID of the print job to delete
     * @return a "No Content" response if the print job is deleted,
     * or a "Not Found" response if the print job is not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePrintJob(@PathVariable("id") String id) {
        Optional<PrintJob> printJob = printJobRepository.findById(new ObjectId(id));
        if (printJob.isPresent()) {
            if(printJob.get().getFileId() != null && fileRepository.findById(printJob.get().getFileId()).isPresent()) {
                fileRepository.deleteById(printJob.get().getFileId());
            }
            printJobRepository.deleteById(new ObjectId(id));
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Deletes an archived print job with the specified ID.
     *
     * @param id the ID of the archived print job to delete
     * @return a "No Content" response if the archived print job is deleted,
     * or a "Not Found" response if the archived print job is not found
     */
    @DeleteMapping("/archived/{id}")
    public ResponseEntity<?> deleteArchivedPrintJob(@PathVariable("id") String id) {
        Optional<ArchivedPrintJob> archivedPrintJob = archivedPrintJobRepository.findById(new ObjectId(id));
        if (archivedPrintJob.isPresent()) {
            archivedPrintJobRepository.deleteById(new ObjectId(id));
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Validates a print job and returns a map of validation errors.
     *
     * @param printJobData the data to validate
     * @return a map containing the validation errors, if any
     */
    private Map<String, String> getValidationErrors(PrintJobData printJobData) {
        Map<String, String> validationErrors = new HashMap<>();

        if (printJobData.getName() == null || printJobData.getName().length() > 255) {
            validationErrors.put("name", "Name must not be null and should have a maximum length of 255 characters.");
        }

        if (printJobData.getEmail() == null || printJobData.getEmail().length() > 255) {
            validationErrors.put("email", "Email must not be null and should have a maximum length of 255 characters.");
        }

        if (PrintJobData.isNotValidEmail(printJobData.getEmail())) {
            validationErrors.put("email", "Invalid email address.");
        }

        if (printJobData.getDescription() == null || printJobData.getDescription().length() > 1000) {
            validationErrors.put("description", "Description must not be null and should have a maximum length of 1000 characters.");
        }

        return validationErrors;
    }

    private boolean isEmail(String input) {
        // Check if the input is a valid email address
        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return input.matches(emailPattern);
    }
}