package com.algonquincollege.makerqueue.utill;

import java.util.HashMap;
import java.util.Map;

public enum Priority {
    NORMAL("Normal"),
    HIGH("High"),
    PROJECT("Project");

    // Create a reverse mapping from string to enum value
    private static final Map<String, Priority> priorityStringMap = new HashMap<>();

    static {
        for (Priority priority : values()) {
            priorityStringMap.put(priority.priorityString, priority);
        }
    }

    private final String priorityString;

    Priority(String priorityString) {
        this.priorityString = priorityString;
    }

    // Setter method to set the priority from a string
    public static Priority setPriorityFromString(String priorityString) {
        Priority priority = priorityStringMap.get(priorityString);
        if (priority == null) {
            throw new IllegalArgumentException("Invalid priority string: " + priorityString);
        }
        return priority;
    }

    @Override
    public String toString() {
        return priorityString;
    }
}
