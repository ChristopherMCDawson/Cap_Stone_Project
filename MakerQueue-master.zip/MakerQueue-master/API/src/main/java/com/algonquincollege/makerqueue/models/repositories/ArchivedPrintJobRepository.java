/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue.models.repositories;

import com.algonquincollege.makerqueue.models.ArchivedPrintJob;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * The ArchivedPrintJobRepository interface extends the MongoRepository interface,
 * providing methods for accessing and managing archived print jobs in the database.
 * It uses UUID as the identifier type for print jobs.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-10-05
 */
public interface ArchivedPrintJobRepository extends MongoRepository<ArchivedPrintJob, ObjectId> {
    List<ArchivedPrintJob> findByPrintJobDataNameContainingIgnoreCase(String name);

    List<ArchivedPrintJob> findByPrintJobDataEmailContainingIgnoreCase(String email);
}
