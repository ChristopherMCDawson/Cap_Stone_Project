/*
 *  This application is the property of Algonquin College.
 *  Unauthorized reproduction or distribution of this application, or any portion of it,
 *  is strictly prohibited.
 *  Copyright (c) 2023. Algonquin College. All rights reserved.
 */

package com.algonquincollege.makerqueue.models;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Year;

/**
 * Represents a print job with a unique identifier, name, email, and description.
 *
 * @author Mohamad Chaaban
 * @version 1.0
 * @since 2023-06-26
 */
@Document(collection = "printjobs")
public class PrintJob {
    @Id
    @Indexed(unique = true)
    private ObjectId uuid;
    private PrintJobData printJobData;

    public PrintJob(ArchivedPrintJob archivedPrintJob) {
        PrintJobData tempData = archivedPrintJob.getPrintJobData();
        PrintJobData.validate(tempData.getName(), tempData.getEmail(), tempData.getDescription());
        this.uuid = new ObjectId(archivedPrintJob.getUuid());
        printJobData = new PrintJobData(tempData.getName(), tempData.getEmail(), tempData.getDescription(), tempData.getFileId());
    }

    public PrintJob(PrintJobData printJobData) {
        this.uuid = new ObjectId();
        String JobID = Year.now().toString() + this.uuid.toString().substring(this.uuid.toString().length() - 5);
        printJobData.setJobID(JobID);
        this.printJobData = printJobData;
    }

    public PrintJob() {
    }

    public PrintJobData getPrintJobData() {
        return printJobData;
    }

    public String getUuid() {
        return uuid.toString();
    }

    public void setUuid(String uuid) {
        this.uuid = new ObjectId(uuid);
    }

    public String getName() {
        return printJobData.getName();
    }

    public String getEmail() {
        return printJobData.getEmail();
    }

    public String getDescription() {
        return printJobData.getDescription();
    }

    public String getStatus() {
        return printJobData.getStatus();
    }

    public String getFileId() {
        return printJobData.getFileId();
    }

    public void setFileId(String fileId) {
        printJobData.setFileId(fileId);
    }

    public String getPriority() {
        return printJobData.getPriority();
    }

    public String getJobID() {
        return printJobData.getJobID();
    }
}
