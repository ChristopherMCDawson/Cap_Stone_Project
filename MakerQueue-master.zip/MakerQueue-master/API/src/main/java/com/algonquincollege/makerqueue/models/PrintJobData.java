package com.algonquincollege.makerqueue.models;

import com.algonquincollege.makerqueue.utill.Priority;
import com.algonquincollege.makerqueue.utill.Status;

public class PrintJobData {
    private String name;
    private String email;
    private String description;
    private Status status;
    private Priority priority;
    private String jobID;

    private String fileId;

    public PrintJobData(String name, String email, String description, String fileId) {
        PrintJobData.validate(name, email, description);
        this.name = name;
        this.email = email;
        this.description = description;
        this.fileId = fileId;
        status = Status.TO_DO;
        priority = Priority.NORMAL;
    }

    public static boolean isAlgonquinEmail(String email) {
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&*-]+)*@(?:algonquinlive|algonquincollege)\\.com$";
        return email.matches(regex);
    }

    public static void validate(String name, String email, String description) {
        if (name == null || name.length() > 255
                || email == null || email.length() > 255
                || isNotValidEmail(email)
                || description == null || description.length() > 1000)
            throw new IllegalArgumentException();
    }

    public static boolean isNotValidEmail(String email) {
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return !email.matches(regex);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status.toString();
    }

    public void setStatus(String status) {
        this.status = Status.setStatusFromString(status);
    }

    public String getPriority() {
        return priority.toString();
    }

    public void setPriority(String priority) {
        this.priority = Priority.setPriorityFromString(priority);
    }

    public String getFileId() {
        return this.fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getJobID() {
        return this.jobID;
    }

    public void setJobID(String jobID) {
        this.jobID = jobID;
    }
}
