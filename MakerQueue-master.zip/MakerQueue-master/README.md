# MakerQueue

SF2023 Project Team - MakerQueue \
Team Members:

- Joshua Bernstein-Mason
- Mohamad Chaaban
- Christopher Decarie-Dawson
- Jadon Belair
- Soomin Lee \
\
The client has requested a Web Application solution that implements a queueing system allowing a user to view and create
3D print job requests.
The application must use a Web Portal to allow local and remote access to gather the Name, Email, 3D Print description,
and use this information
to create a generated ID to streamline tracking. The project will solve issues that result from having no queueing
system in place for the 3D Printers
in the Makerspace on Algonquin College Woodroffe Campus. Currently, an excel spreadsheet is being used to track 3D print
jobs which is not adequate for
the volume of requests and emails received to the Makerspace Shared Mailbox.

## Contributing

### Downloading MongoDB Compass on Windows

1. Go to the MongoDB Download Center
   website: [https://www.mongodb.com/try/download/compass](https://www.mongodb.com/try/download/compass).

2. Scroll down to the "MongoDB Compass" section and click on the "Download" button for the Windows version.

3. Once the download is complete, locate the downloaded installer file and double-click on it to start the installation
   process.

4. Follow the on-screen instructions to install MongoDB Compass on your Windows machine. Choose the desired installation
   options and click "Next" or "Install" to proceed.

5. Once the installation is complete, you can launch MongoDB Compass by searching for it in the Start menu or by
   double-clicking on its desktop shortcut.

### Setting up a Local Server with MongoDB Compass

1. Launch MongoDB Compass.

2. In the initial connection screen, leave the default settings as they are.

3. Click on the "Connect" button to connect to a local MongoDB server.

4. If you don't have a MongoDB server installed locally, you can set up a new one by clicking on the "Create New" button
   in the "New Connection" tab.

5. In the "Connection Settings" tab, configure the following settings:
    - **Hostname**: Set it to "localhost".
    - **Port**: Set it to the default MongoDB port, which is 27017.
    - **Authentication**: Choose the appropriate authentication method if required. For a local server, you can usually
      leave it as "None".

6. Click on the "Connect" button to connect to the local MongoDB server.

7. Once connected, you will see the server listed on the left-hand side of the MongoDB Compass window.

8. To create a new database, right-click on the server name and select "Create Database". Enter "makerqueue" as the
   database name and click "Create".

9. To create a collection called "printjobs" within the "makerqueue" database, click on the "makerqueue" database name
   in the left-hand navigation panel, then click on the "Create Collection" button. Enter "printjobs" as the collection
   name and click "Create".

10. You have now set up a local server with MongoDB Compass and created a database called "makerqueue" with a collection
    called "printjobs". You can start adding and managing documents in the "printjobs" collection.

Make sure to refer to the MongoDB Compass documentation for more details on using the Compass interface and interacting
with MongoDB databases: [https://docs.mongodb.com/compass/current/](https://docs.mongodb.com/compass/current/).
