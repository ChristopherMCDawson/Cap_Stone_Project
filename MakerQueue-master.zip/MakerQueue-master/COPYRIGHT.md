# COPYRIGHT

This application is the property of Algonquin College.
Unauthorized reproduction or distribution of this application, or any portion of it,
is strictly prohibited.
Copyright (c) 2023. Algonquin College. All rights reserved.
