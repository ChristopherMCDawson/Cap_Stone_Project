import React, { useEffect, useState } from "react";
import { Table } from "react-bootstrap";

const Client_List = ({ entries }) => {
  const [sortColumn, setSortColumn] = useState("name");
  const [sortDirection, setSortDirection] = useState("asc");
  const [sortedEntries, setSortedEntries] = useState([]);

  useEffect(() => {
    const sortedData = [...entries].sort((a, b) => {
      const aValue = a[sortColumn];
      const bValue = b[sortColumn];

      if (sortDirection === "asc") {
        return aValue.localeCompare(bValue);
      } else {
        return bValue.localeCompare(aValue);
      }
    });
    setSortedEntries(sortedData);
  }, [entries, sortColumn, sortDirection]);
  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }

    const sortedData = [...entries].sort((a, b) => {
      const aValue = a[column];
      const bValue = b[column];

      if (sortDirection === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });
    setSortedEntries(sortedData);
  };

  return (
    <div style={{ overflow: "scroll", height: "200px" }}>
      <Table striped bordered hover size="sm" style={{ minWidth: "100%" }}>
        <thead>
          <tr>
            <th>Job Id</th>
            <th onClick={() => handleSort("name")}>
              Name
              {sortColumn === "name" && sortDirection === "asc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-up"
                  viewBox="0 0 16 16"
                >
                  {/* Up arrow icon */}
                </svg>
              )}
              {sortColumn === "name" && sortDirection === "desc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-down-alt"
                  viewBox="0 0 16 16"
                >
                  {/* Down arrow icon */}
                </svg>
              )}
            </th>
            <th onClick={() => handleSort("email")}>
              Email
              {sortColumn === "email" && sortDirection === "asc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-up"
                  viewBox="0 0 16 16"
                >
                  {/* Up arrow icon */}
                </svg>
              )}
              {sortColumn === "email" && sortDirection === "desc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-down-alt"
                  viewBox="0 0 16 16"
                >
                  {/* Down arrow icon */}
                </svg>
              )}
            </th>
            <th>Description</th>
            {
              <th onClick={() => handleSort("status")}>
                Status
                {sortColumn === "status" && sortDirection === "asc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-up"
                    viewBox="0 0 16 16"
                  >
                    {/* Up arrow icon */}
                  </svg>
                )}
                {sortColumn === "status" && sortDirection === "desc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-down-alt"
                    viewBox="0 0 16 16"
                  >
                    {/* Down arrow icon */}
                  </svg>
                )}
              </th>
            }
            {
              <th onClick={() => handleSort("priority")}>
                Priority
                {sortColumn === "priority" && sortDirection === "asc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-up"
                    viewBox="0 0 16 16"
                  >
                    {/* Up arrow icon */}
                  </svg>
                )}
                {sortColumn === "priority" && sortDirection === "desc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-down-alt"
                    viewBox="0 0 16 16"
                  >
                    {/* Down arrow icon */}
                  </svg>
                )}
              </th>
            }
          </tr>
        </thead>
        <tbody>
          {sortedEntries.map((entry) => (
            <tr key={entry.uuid}>
              <td>{entry.jobID}</td>
              <td>{entry.name}</td>
              <td>{entry.email}</td>
              <td>{entry.description}</td>
              <td>{entry.status}</td>
              <td>{entry.priority}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default Client_List;
