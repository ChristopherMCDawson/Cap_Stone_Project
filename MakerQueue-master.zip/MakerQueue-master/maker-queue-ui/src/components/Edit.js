import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const BASE_URL = "http://localhost:8080/api/printjobs";

const Edit = ({ onEdit }) => {
  const { uuid } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    description: "",
    priority: "",
    status: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [statusOptions, setStatusOptions] = useState([]);
  const [priorityOptions, setPriorityOptions] = useState([]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await axios.put(`${BASE_URL}/${uuid}`, formData);
      onEdit(response.data);
    } catch (error) {
      setError("Error updating entry");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    axios.get(`${BASE_URL}/${uuid}`).then((response) => {
      const entryData = response.data;
      setFormData({
        name: entryData.name,
        email: entryData.email,
        description: entryData.description,
        priority: entryData.priority,
        status: entryData.status,
      });
    });
  }, [uuid, onEdit]);

  useEffect(() => {
    axios
      .get(`${BASE_URL}/status`)
      .then((response) => {
        setStatusOptions(response.data);
      })
      .catch((err) => {
        console.error("Error fetching status options", err);
      });
    axios
      .get(`${BASE_URL}/priority`)
      .then((response) => {
        setPriorityOptions(response.data);
      })
      .catch((err) => {
        console.error("Error fetching priority options", err);
      });
  }, []);

  return (
    <div className="container mt-4">
      <h2>Edit Entry</h2>
      {error && <p className="text-danger">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="row mb-3">
          <div className="col">
            <label htmlFor="name" className="form-label">
              Name
            </label>
            <input
              type="text"
              name="name"
              id="name"
              value={formData.name}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="col">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <input
              type="email"
              name="email"
              id="email"
              value={formData.email}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="col">
            <label htmlFor="priority" className="form-label">
              Priority
            </label>
            <div className="p-2">
              <select
                name="priority"
                id="priority"
                value={formData.priority}
                onChange={handleChange}
                className="form-control-sm"
                required
              >
                {priorityOptions.map((priorityOption) => (
                  <option key={priorityOption} value={priorityOption}>
                    {priorityOption}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="col">
            <label htmlFor="status" className="form-label">
              Status
            </label>
            <div className="p-2">
              <select
                name="status"
                id="status"
                value={formData.status}
                onChange={handleChange}
                className="form-control-sm"
                required
              >
                {statusOptions.map((statusOption) => (
                  <option key={statusOption} value={statusOption}>
                    {statusOption}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <input
            type="file"
            name="files"
            id="files"
            // onChange={handleFileChange}
            className="form-control form-control-lg"
          />
        </div>

        <div className="mb-3">
          <label htmlFor="description" className="form-label">
            Description
          </label>
          <textarea
            name="description"
            id="description"
            value={formData.description}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="d-flex justify-content-between">
          <button
            type="submit"
            className="btn btn-primary"
            onClick={() => navigate(-1)}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save"}
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => navigate(-1)}
          >
            Back
          </button>
        </div>
      </form>
    </div>
  );
};

export default Edit;
