import React, {useState} from "react";
import {useNavigate} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [isUsernameAvailable, setIsUsernameAvailable] = useState(true);
    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();

        const isExistingUsername = existingUsernames.includes(username.toLowerCase());
        if (isExistingUsername) {
            if(password=== "masterkey") {
                navigate("/home", {state:{username}});
            } else {
                window.alert("Username exists but wrong password")
            }
        } else {
            const shouldRegister = window.confirm("Username not found. Do you want to register?");
            if (shouldRegister) {
                existingUsernames.push(username.toLowerCase());
                navigate("/home", {state: {username}});
            } else {
                window.alert("Registration canceled");
            }
        }
    };

    const existingUsernames = ["admin", "tech1", "tech2", "tech3"];
    const checkUsernameAvailability = () => {
        const isAvailable = !existingUsernames.includes(username.toLowerCase());
        setIsUsernameAvailable(isAvailable);
    };
    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <div className="card" style={{marginBottom: 100}}>
                        <div className="card-header">
                            <h3 className="mb-0">Submit Project</h3>
                        </div>
                        <div className="card-body">
                            <button className="btn btn-lg btn-success" type="submit"
                                    onClick={() => navigate("./Client_UI")}>Submit Project
                            </button>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-header">
                            <h3 className="mb-0">Login or Register</h3>
                        </div>
                        <div className="card-body">
                            <form className="form-signin" onSubmit={handleLogin}>
                                <input type="text"
                                       id="username"
                                       className={`form-control ${
                                           isUsernameAvailable ? "" : "is-invalid"
                                       }`}
                                       placeholder="Username"
                                       onChange={(e) => {
                                           setUsername(e.target.value);
                                           checkUsernameAvailability();
                                       }} style={{marginBottom: 10}}
                                />
                                <input
                                    type="password"
                                    id="password"
                                    className="form-control"
                                    placeholder="Password"
                                    onChange={(e) => setPassword(e.target.value)}
                                    style={{marginBottom: 10}}
                                />
                                {isUsernameAvailable || (
                                    <div className="invalid-feedback">Username already exists</div>
                                )}
                                <button
                                    className="btn btn-lg btn-primary btn-block"
                                    type="submit"
                                    disabled={!isUsernameAvailable}
                                >
                                    Login
                                </button>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
