import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Table } from "react-bootstrap";
import axios from "axios";

const FILE_URL = "http://localhost:8080/api/files";

const List = ({
  entries,
  handleArchiveUnarchive,
  handleDelete,
  displayArchived,
}) => {
  const [sortColumn, setSortColumn] = useState("name");
  const [sortDirection, setSortDirection] = useState("asc");
  const [sortedEntries, setSortedEntries] = useState([]);

  useEffect(() => {
    const sortedData = [...entries].sort((a, b) => {
      const aValue = a[sortColumn];
      const bValue = b[sortColumn];

      if (sortDirection === "asc") {
        return aValue.localeCompare(bValue);
      } else {
        return bValue.localeCompare(aValue);
      }
    });
    setSortedEntries(sortedData);
  }, [entries, sortColumn, sortDirection]);
  const onDelete = async (uuid, isArchived) => {
    if (isArchived) {
      const confirmDelete = window.confirm(
        "Are you sure you want to delete this archived entry?"
      );
      if (!confirmDelete) {
        return;
      }
    }
    await handleDelete(uuid, isArchived);
  };
  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }

    const sortedData = [...entries].sort((a, b) => {
      const aValue = a[column];
      const bValue = b[column];

      if (sortDirection === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });
    setSortedEntries(sortedData);
  };

  const handleDownload = async (fileId) => {
    try {
      const response = await axios.get(`${FILE_URL}/${fileId}`, {
        responseType: "blob", // Important
      });

      // Create a Blob from the PDF Stream
      const file = new Blob([response.data], {
        type: response.headers["content-type"],
      });

      const fileURL = URL.createObjectURL(file);

      const fileLink = document.createElement("a");
      fileLink.href = fileURL;
      console.log(response.headers["content-disposition"]);

      const response2 = await axios.get(`${FILE_URL}/name/${fileId}`);
      let filename = response2.data;
      console.log(filename);
      fileLink.setAttribute("download", filename);

      document.body.appendChild(fileLink);

      // Programmatically click the link to trigger the download
      fileLink.click();

      // Clean up and remove the link
      fileLink.parentNode.removeChild(fileLink);
    } catch (error) {
      console.error("Error during file download", error);
    }
  };

  return (
    <div style={{ overflow: "scroll", height: "200px" }}>
      <Table striped bordered hover size="sm" style={{ minWidth: "100%" }}>
        <thead>
          <tr>
            <th>Job Id</th>
            <th onClick={() => handleSort("name")}>
              Name
              {sortColumn === "name" && sortDirection === "asc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-up"
                  viewBox="0 0 16 16"
                >
                  {/* Up arrow icon */}
                </svg>
              )}
              {sortColumn === "name" && sortDirection === "desc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-down-alt"
                  viewBox="0 0 16 16"
                >
                  {/* Down arrow icon */}
                </svg>
              )}
            </th>
            <th onClick={() => handleSort("email")}>
              Email
              {sortColumn === "email" && sortDirection === "asc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-up"
                  viewBox="0 0 16 16"
                >
                  {/* Up arrow icon */}
                </svg>
              )}
              {sortColumn === "email" && sortDirection === "desc" && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-sort-down-alt"
                  viewBox="0 0 16 16"
                >
                  {/* Down arrow icon */}
                </svg>
              )}
            </th>
            <th>Description</th>
            {!displayArchived && (
              <th onClick={() => handleSort("status")}>
                Status
                {sortColumn === "status" && sortDirection === "asc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-up"
                    viewBox="0 0 16 16"
                  >
                    {/* Up arrow icon */}
                  </svg>
                )}
                {sortColumn === "status" && sortDirection === "desc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-down-alt"
                    viewBox="0 0 16 16"
                  >
                    {/* Down arrow icon */}
                  </svg>
                )}
              </th>
            )}
            {!displayArchived && (
              <th onClick={() => handleSort("priority")}>
                Priority
                {sortColumn === "priority" && sortDirection === "asc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-up"
                    viewBox="0 0 16 16"
                  >
                    {/* Up arrow icon */}
                  </svg>
                )}
                {sortColumn === "priority" && sortDirection === "desc" && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-sort-down-alt"
                    viewBox="0 0 16 16"
                  >
                    {/* Down arrow icon */}
                  </svg>
                )}
              </th>
            )}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {sortedEntries.map((entry) => (
            <tr key={entry.uuid}>
              <td>{entry.jobID}</td>
              <td>{entry.name}</td>
              <td>{entry.email}</td>
              <td>{entry.description}</td>
              {!displayArchived && <td>{entry.status}</td>}
              {!displayArchived && <td>{entry.priority}</td>}
              <td>
                <button
                  className="btn btn-danger btn-sm ml-2"
                  onClick={() => onDelete(entry.uuid, displayArchived)}
                  style={{ marginRight: 5 }}
                >
                  Delete
                </button>
                {!displayArchived && (
                  <button className="btn btn-warning btn-sm ml-2">
                    <Link to={`/Edit/${entry.uuid}`}>Edit</Link>
                  </button>
                )}
                {displayArchived && (
                  <button
                    className="btn btn-success btn-sm ml-2"
                    onClick={() => handleArchiveUnarchive(entry.uuid, false)}
                  >
                    Unarchive
                  </button>
                )}
                {!displayArchived && entry.fileId && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handleDownload(entry.fileId)}
                  >
                    Download File
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default List;
