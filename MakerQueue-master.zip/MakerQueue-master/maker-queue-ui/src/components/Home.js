import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Create from "./Create";
import Search from "./Search";
import { useLocation } from "react-router-dom";

const BASE_URL = "http://localhost:8080/api/printjobs";

const Home = () => {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [displayArchived, setDisplayArchived] = useState(false);
  const location = useLocation();
  const username = location.state?.username;

  const fetchEntries = async () => {
    try {
      setLoading(true);
      setError("");
      const url = displayArchived ? `${BASE_URL}/archived` : `${BASE_URL}`;
      const response = await axios.get(url);
      setEntries(response.data);
    } catch (error) {
      setError("Error fetching entries");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntries();
  }, [displayArchived]);
  const handleArchiveUnarchive = async (uuid, archive) => {
    try {
      const action = archive ? "archive" : "unarchive";
      await axios.post(`${BASE_URL}/${uuid}/${action}`);
      fetchEntries(); // Refresh the entries after archiving or unarchiving
    } catch (error) {
      setError(`Error ${archive ? "archiving" : "unarchiving"} entry`);
    }
  };

  const handleDelete = async (uuid, isArchived) => {
    try {
      const endpoint = isArchived ? `/archived/${uuid}` : `/${uuid}`;
      await axios.delete(`${BASE_URL}${endpoint}`);
      fetchEntries(); // Refresh the entries after deletion
    } catch (error) {
      setError(`Error deleting entry: ${error.message}`);
    }
  };

  const handleCreate = (newEntry) => {
    setEntries((prevEntries) => [...prevEntries, newEntry]);
  };

  const handleEdit = async (editedEntry, selectedStatus) => {
    try {
      // Update the entry's status
      const updatedEntry = { ...editedEntry, status: selectedStatus };

      // Make a PUT request to update the entry
      await axios.put(`${BASE_URL}/${editedEntry.uuid}`, updatedEntry);

      // Update the local state with the edited entry
      setEntries((prevEntries) =>
        prevEntries.map((entry) =>
          entry.uuid === editedEntry.uuid ? updatedEntry : entry
        )
      );
      if (fetchEntries) {
        fetchEntries();
      }
    } catch (error) {
      setError("Error updating status");
    }
  };

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-start">
        <div
          className="btn-group btn-group-sm"
          role="group"
          aria-label="Print Jobs / Archived Jobs"
        >
          <button
            type="button"
            className={`btn btn-outline-primary btn-sm ${
              !displayArchived ? "active" : ""
            }`}
            onClick={() => setDisplayArchived(false)}
          >
            Print Jobs
          </button>
          <button
            type="button"
            className={`btn btn-outline-secondary btn-sm ${
              displayArchived ? "active" : ""
            }`}
            onClick={() => setDisplayArchived(true)}
          >
            Archived Jobs
          </button>
        </div>
      </div>
      <div className="d-flex justify-content-center">
        <h1 className="mb-4">
          {displayArchived ? "Archived Jobs" : "Print Jobs List"}
        </h1>
      </div>
      <div>
        {!displayArchived && <Create onCreate={handleCreate} />}
        <Search
          entries={entries}
          loading={loading}
          error={error}
          handleArchiveUnarchive={handleArchiveUnarchive}
          handleDelete={handleDelete}
          handleEdit={handleEdit}
          displayArchived={displayArchived}
          fetchEntries={fetchEntries}
        />
      </div>
    </div>
  );
};
export default Home;
