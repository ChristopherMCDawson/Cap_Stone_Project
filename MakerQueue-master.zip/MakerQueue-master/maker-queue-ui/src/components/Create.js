import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";

const BASE_URL = "http://localhost:8080/api/printjobs";
const FILE_URL = "http://localhost:8080/api/files";

const Create = ({ onCreate }) => {
  useEffect(() => {
    axios
      .get(`${BASE_URL}/priority`)
      .then((response) => {
        setPriorityOptions(response.data);
      })
      .catch((err) => {
        console.error("Error fetching priority options", err);
      });
  }, []);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [priorityOptions, setPriorityOptions] = useState([]);
  const [files, setFiles] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    description: "",
    priority: priorityOptions[0],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    setFiles(Array.from(e.target.files));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      let requestFormData = formData;

      let fileIds = await Promise.all(
        files.map(async (fileToUpload) => {
          let fileFormData = new FormData();
          fileFormData.append("file", fileToUpload);

          let response = await axios.post(`${FILE_URL}/upload`, fileFormData, {
            // lets the api know that a file is attached
            headers: {
              "Content-Type": "multipart/form-data",
            },
          });

          return response.data;
        })
      );

      // adds the returned file ID's to the print job data
      requestFormData.fileId = fileIds[0];
      const response = await axios.post(BASE_URL, requestFormData);

      onCreate(response.data);

      setFormData({
        name: "",
        email: "",
        description: "",
        priority: "",
      });
      setFiles([]);
    } catch (error) {
      console.error(error);
      setError("Error creating entry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4" style={{ marginBottom: "20px" }}>
      <h2>Create Entry</h2>
      {error && <p className="text-danger">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="container">
          <div className="row">
            <div className="col-md-8">
              <div className="mb-3 row">
                <label htmlFor="name" className="col-sm-2 col-form-label">
                  Name
                </label>
                <div className="col-sm-10">
                  <input
                    type="text"
                    name="name"
                    id="name"
                    placeholder="Name"
                    value={formData.name}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>
              </div>
              <div className="mb-3 row">
                <label htmlFor="email" className="col-sm-2 col-form-label">
                  Email
                </label>
                <div className="col-sm-10">
                  <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>
              </div>
              <div className="mb-3 row">
                <label
                  htmlFor="description"
                  className="col-sm-2 col-form-label"
                >
                  Description
                </label>
                <div className="col-sm-10">
                  <textarea
                    name="description"
                    id="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>
              </div>
            </div>
            <div className="col-6 col-md-4">
              <div className="mb-3">
                <input
                  type="file"
                  name="files"
                  id="files"
                  onChange={handleFileChange}
                  className="form-control form-control-lg"
                />
              </div>
              <div>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {loading ? "Creating..." : "Create"}
                </button>
              </div>
            </div>
          </div>
        </div>
        <div>
          <label htmlFor="priority" className="form-label">
            Priority:
          </label>
          <select
            name="priority"
            id="priority"
            value={formData.priority}
            onChange={handleChange}
            className="form-control"
            required
          >
            {priorityOptions.map((priorityOption) => (
              <option key={priorityOption} value={priorityOption}>
                {priorityOption}
              </option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? "Creating..." : "Create"}
        </button>
      </form>
    </div>
  );
};

export default Create;
