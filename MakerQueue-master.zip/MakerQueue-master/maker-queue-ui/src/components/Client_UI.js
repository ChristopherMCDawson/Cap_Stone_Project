import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Create from "./Create";
import Client_Search from "./Client_Search";
import axios from "axios";

const BASE_URL = "http://localhost:8080/api/printjobs";

const Client_UI = () => {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    fetchEntries();
  }, []);
  const fetchEntries = async () => {
    try {
      setLoading(true);
      setError("");
      const url = `${BASE_URL}`;
      const response = await axios.get(url);
      setEntries(response.data);
    } catch (error) {
      setError("Error fetching entries");
    } finally {
      setLoading(false);
    }
  };
  const handleCreate = (newEntry) => {
    alert("New entry created successfully");
    setEntries((prevEntries) => [...prevEntries, newEntry]);
  };

  return (
    <div>
      <h1>Client UI</h1>
      <Create onCreate={handleCreate} />
      <Client_Search entries={entries} />
    </div>
  );
};
export default Client_UI;
