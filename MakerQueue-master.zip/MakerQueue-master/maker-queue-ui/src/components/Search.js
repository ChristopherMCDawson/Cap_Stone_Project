import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import List from "./List";

const BASE_URL = "http://localhost:8080/api/printjobs";

const Search = ({
  entries,
  handleArchiveUnarchive,
  handleDelete,
  handleEdit,
  displayArchived,
}) => {
  const [results, setResults] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchEntries = async () => {
    try {
      setLoading(true);
      setError("");

      let response;
      if (searchQuery) {
        const endpoint = displayArchived ? "/archived/search" : "/search";
        response = await axios.get(BASE_URL + endpoint, {
          params: {
            query: searchQuery,
          },
        });
      } else {
        const endpoint = displayArchived ? "/archived" : "";
        response = await axios.get(BASE_URL + endpoint);
      }

      if (response.data) {
        setResults(response.data);
      } else {
        setResults([]);
        setError("No matching entries found.");
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntries();
  }, [searchQuery, displayArchived, entries]);

  return (
    <div className="container mt-4">
      <form onSubmit={(e) => e.preventDefault()}>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Enter Job ID, Name, or Email"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />{" "}
          <button
            type="button"
            className="btn btn-primary"
            onClick={fetchEntries}
          >
            {loading ? "Searching..." : "Search"}{" "}
          </button>{" "}
        </div>{" "}
      </form>{" "}
      {error && <p className="text-danger"> {error} </p>}{" "}
      <List
        entries={results}
        loading={loading}
        error={error}
        handleArchiveUnarchive={handleArchiveUnarchive}
        handleDelete={handleDelete}
        handleEdit={handleEdit}
        displayArchived={displayArchived}
        fetchEntries={fetchEntries}
      />
    </div>
  );
};

export default Search;
