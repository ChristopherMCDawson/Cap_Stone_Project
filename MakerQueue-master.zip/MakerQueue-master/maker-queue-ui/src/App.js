import React from 'react'
import { BrowserRouter as Router, Route, Routes }
    from 'react-router-dom';
import './App.css';
import {AuthProvider} from "./components/AuthContext";
import Create from './components/Create';
import Edit from './components/Edit';
import Home from './components/Home';
import Search from './components/Search';
import List from './components/List';
import Login from './components/Login';
import Client_UI from "./components/Client_UI";
  
function App() {
    return (
        <div className='App'>
  <AuthProvider>
            <Router>
                <Routes>
                    <Route path='/'
                        element={<Login />} />
                    <Route path='/home'
                        element={<Home />} />
                    <Route path='/client_ui'
                        element={<Client_UI />} />
                    <Route path='/create' 
                        element={<Create />} />
                    <Route path='/edit/:uuid'
                        element={<Edit />} />
                    <Route path='/search'
                        element={<Search />} />
                    <Route path='/list'
                        element={<List />} />
                </Routes>
            </Router>
  </AuthProvider>
        </div>
    );
}
  
export default App;